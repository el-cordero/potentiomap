potentiomap 0.1.0 example GIS products
=======================================

Generated: 2026-07-13
Source data: released synthetic_wells data from potentiomap 0.1.0.
CRS: EPSG:26916 (NAD83 / UTM zone 16N); horizontal units are metres.
Head units: synthetic elevation units; no vertical datum is implied.

Contents include TPS and IDW GeoTIFF surfaces, contour shapefile components,
native quicklook PNGs, a multiband hydraulic-gradient GeoTIFF, arrow lines,
arrow sample points, arrow tips and bases, and the exact reproduction script.

Arrows indicate decreasing modeled head. They are not groundwater velocity,
travel-time, particle-path, or contaminant-transport products.
